from cgi import print_form
import os
import shutil
from pathlib import Path
import time

""""
    Module docstring
"""
def backup(arquivo_backup):
    """

        Essa função verifica se há arquivos descritos no Backup.parm para fazer o backup
        Caso impossível
        
        Inputs:
            :backup: Variavél que contém o arquivo backup.parm 
        Returns:
            :: Retorna Verdadeiro caso possua arquivos para backup
            :: Retorna falso caso não tenha arquivos para backup

        Assertivas de Entrada:
            :arquivo_backup: arquivo com nomes dos arquivos necessários para o backup
    """
    backup = open(arquivo_backup, "r")

    if backup.readline() == "":
        return False
    else:
        return True

def HD_PenDrive(dir_HD, dir_PD, arquivo):
    """

        Essa função faz o backup de arquivos entre o HD e um Pendrive, quando o ArqX pertence ao HD
        Caso HD para PenDrive
        
        Inputs:
            :origem: Nome da pasta de origem dos arquivos a serem transferidos
            :destino: Nome da pasta de destino dos arquivos transferidos 
            :backup: Arquivo Backup.parm para leitura dos arquivos a serem transferidos
            :linha: Linha do arquivo Backup.parm
            :files: arquivos contidos no diretório de origem
            :name: nome do arquivo a ser transferido
        Returns:
            :: Retorna Verdadeiro quando feito a transferência dos arquivos

        Assertivas de Entrada:
            :dir_HD: Nome da pasta de origem
            :dir_PD: Nome da pasta de destino
            :arquivo: Nome do arquivo para leitura (backup.parm)
    """
    origem = dir_HD
    destino = dir_PD

    #Leitura do Backup.parm
    backup = open(arquivo, "r")
    linha = backup.readline().replace("\n", "")

    #pega todos os arquivos do HD
    files = os.listdir(origem)

    #Verificação dos arquivos a serem copiados
    while(linha != ""):
        for name in files:
            if name == linha:
                shutil.copy2(os.path.join(origem,name), destino)
        linha = backup.readline().replace("\n", "")     

    return True

def True_Backup(dir_HD, dir_PD,arquivo):
    """

        Essa função faz o backup de arquivos entre o HD e um Pendrive
        São testados 3 casos nesta função sendo elas: PenD > HD (Erro), PenD < HD(HD para Pendrive), PenD == HD (Faz nada)
        
        Inputs:           
            :origem: Nome da pasta de origem dos arquivos a serem transferidos
            :destino: Nome da pasta de destino dos arquivos transferidos 
            :backup: Arquivo Backup.parm para leitura dos arquivos a serem transferidos
            :linha: Linha do arquivo Backup.parm
            :files_origem: arquivos contidos no diretório de origem
            :files_destino: arquivos contidos no diretório de destino
            :name_origem: nome do arquivo na pasta origem
            :name_destino: nome do arquivo na pasta destino
            :tmod_origem: data do arquivo na pasta origem
            :tmod_destino: data do arquivo na pasta destino
        Returns:
            :: Retorna Verdadeiro quando feito a transferência dos arquivos
            :: Retorna Falso caso a data do Pendrive for maior do que o data do HD
            :: Retorna Nada caso a data do Pendrive for igual do que o data do HD

        Assertivas de Entrada:
            :dir_HD: Nome da pasta de origem
            :dir_PD: Nome da paste de destino            
            :arquivo: Nome do arquivo para leitura (backup.parm)
    """
    origem = dir_HD
    destino = dir_PD

    #Leitura do Backup.parm
    backup = open(arquivo, "r")
    linha = backup.readline().replace("\n", "")

    #pega todos os arquivos do HD
    files_origem = os.listdir(origem)
    files_destino = os.listdir(destino)

    #Verificação dos arquivos a serem copiados
    while(linha != ""):
        for name_origem in files_origem:            
           if name_origem == linha:
            os.chdir(origem)
            tmod_origem = os.path.getmtime(name_origem) #Verifica data do arquivo na origem
            os.chdir(r'..')

            for name_destino in files_destino:
                if name_destino == linha:
                    os.chdir(destino)
                    tmod_destino = os.path.getmtime(name_destino) #Verifica data do arquivo no destino

                    if(tmod_origem > tmod_destino):  # PenD < HD
                        os.chdir(r'..')            
                        shutil.copy2(os.path.join(origem,name_origem), destino)
                    if(tmod_origem < tmod_destino): # PenD > HD
                        return False
                    if(tmod_origem == tmod_origem): # PenD == HD 
                        print("Fez nada")

        linha = backup.readline().replace("\n", "")     

    return True

def No_Backup(dir_HD, dir_PD,arquivo):
    """

        Essa função não faz o backup de arquivos entre o HD e um Pendrive
         
        Inputs:           
            :origem: Nome da pasta de origem dos arquivos a serem transferidos
            :destino: Nome da pasta de destino dos arquivos transferidos 
            :backup: Arquivo Backup.parm para leitura dos arquivos a serem transferidos
            :linha: Linha do arquivo Backup.parm
            :cont_files: contador de quantos files tem na pasta
            :cont_names: contador de quantos arquivos foram 
        Returns:
            :: Retorna Falso quando não faz o backup e possui arquivo no HD

        Assertivas de Entrada:
            :dir_HD: Nome da pasta de origem
            :dir_PD: Nome da paste de destino            
            :arquivo: Nome do arquivo para leitura (backup.parm)
    """
    origem = dir_HD
    destino = dir_PD
    cont_files = 0
    cont_names = 0

    #Leitura do Backup.parm
    backup = open(arquivo, "r")
    linha = backup.readline().replace("\n", "")

    #pega todos os arquivos do HD
    files = os.listdir(origem)

    #Verificação dos arquivos a serem copiados
    while(linha != ""):
        for name in files:
            cont_files += 1
            if name != linha:
                cont_names +=1
            else:
                shutil.copy2(os.path.join(origem,name), destino)
        linha = backup.readline().replace("\n", "")     
    
    if cont_files == cont_names:
        return False

def No_Backup2(dir_HD, dir_PD,arquivo):
    """

        Essa função não faz o backup de arquivos entre o HD e um Pendrive
        São testados 3 casos nesta função sendo elas: PenD > HD (Pendrive para HD), PenD < HD (Erro), PenD == HD (Faz nada)
        
        Inputs:           
            :origem: Nome da pasta de origem dos arquivos a serem transferidos
            :destino: Nome da pasta de destino dos arquivos transferidos 
            :backup: Arquivo Backup.parm para leitura dos arquivos a serem transferidos
            :linha: Linha do arquivo Backup.parm
            :files_origem: arquivos contidos no diretório de origem
            :files_destino: arquivos contidos no diretório de destino
            :name_origem: nome do arquivo na pasta origem
            :name_destino: nome do arquivo na pasta destino
            :tmod_origem: data do arquivo na pasta origem
            :tmod_destino: data do arquivo na pasta destino
            
        Returns:
            :: Retorna Falso por não fazer o backup

        Assertivas de Entrada:
            :dir_HD: Nome da pasta de origem
            :dir_PD: Nome da paste de destino            
            :arquivo: Nome do arquivo para leitura (backup.parm)
    """
    origem = dir_HD
    destino = dir_PD

    #Leitura do Backup.parm
    backup = open(arquivo, "r")
    linha = backup.readline().replace("\n", "")

    #pega todos os arquivos do HD
    files_origem = os.listdir(origem)
    files_destino = os.listdir(destino)

    #Verificação dos arquivos a serem copiados
    while(linha != ""):
        for name_origem in files_origem: 
            if name_origem == linha:
                os.chdir(origem)
                tmod_origem = os.path.getmtime(name_origem) #Verifica data do arquivo na origem
                os.chdir(r'..')

                for name_destino in files_destino:
                    if name_destino == linha:
                        os.chdir(destino)
                        tmod_destino = os.path.getmtime(name_destino) #Verifica data do arquivo no destino

                        if(tmod_origem > tmod_destino):  # PenD < HD
                             return False
                        if(tmod_origem == tmod_origem): # PenD == HD 
                            print("Fez nada")
                        if(tmod_origem < tmod_destino):  # PenD > HD
                            os.chdir(r'..')            
                            shutil.copy2(os.path.join(destino,name_origem), origem)

        linha = backup.readline().replace("\n", "")  
    
    return True

def No_Arquivos(dir_HD, dir_PD,arquivo):
    """

        Essa função faz o backup de arquivos entre o HD e um Pendrive, no entando as pastas não possuem o arquivo procurado ou está vazio
               
        Inputs:           
            :origem: Nome da pasta de origem dos arquivos a serem transferidos
            :destino: Nome da pasta de destino dos arquivos transferidos 
            :backup: Arquivo Backup.parm para leitura dos arquivos a serem transferidos
            :linha: Linha do arquivo Backup.parm
            :files_origem: arquivos contidos no diretório de origem
            :files_destino: arquivos contidos no diretório de destino
            :name_origem: nome do arquivo na pasta origem
            :name_destino: nome do arquivo na pasta destino
            :cont: contador para saber se possui o arquivo nas pastas
            
        Returns:
            :: Retorna Falso por ter dado erro na transferência dos dados

        Assertivas de Entrada:
            :dir_HD: Nome da pasta de origem
            :dir_PD: Nome da paste de destino            
            :arquivo: Nome do arquivo para leitura (backup.parm)
    """
    origem = dir_HD
    destino = dir_PD
    cont = 0

    #Leitura do Backup.parm
    backup = open(arquivo, "r")
    linha = backup.readline().replace("\n", "")

    #pega todos os arquivos do HD
    files_origem = os.listdir(origem)
    files_destino = os.listdir(destino)

    #Verifica se as pastas estão vazias
    if files_origem == [] and files_destino == []:
        return False 
    
    #Verificação dos arquivos a serem copiados caso exista
    while(linha != ""):
        for name_origem in files_origem: 
            if name_origem == linha:
                cont += 1
        for name_destino in files_destino:
            if name_destino == linha:
                cont += 1

        linha = backup.readline().replace("\n", "")  

    if cont > 0:
        return True
    else: 
        print("As pastas estão vazias ou não possuem os arquivos desejados")
        return False

def Pd_arquivo(dir_HD, dir_PD,arquivo):
    """

        Essa função faz o backup de arquivos entre o HD e um Pendrive
        É testada na condição de que PenD < HD e o arquivo está presente nas duas pastas
        
        Inputs:           
            :origem: Nome da pasta de origem dos arquivos a serem transferidos
            :destino: Nome da pasta de destino dos arquivos transferidos 
            :backup: Arquivo Backup.parm para leitura dos arquivos a serem transferidos
            :linha: Linha do arquivo Backup.parm
            :files_origem: arquivos contidos no diretório de origem
            :files_destino: arquivos contidos no diretório de destino
            :name_origem: nome do arquivo na pasta origem
            :name_destino: nome do arquivo na pasta destino
            :cont_origem: contador para saber se existe o arquivo desejado na pasta origem
            :cont_destino: contador para saber se existe o arquivo desejado na pasta destino
            
        Returns:
            :: Retorna Verdadeiro quando contabilizado que possui o arquivo no Pendrive e não tem no HD

        Assertivas de Entrada:
            :dir_HD: Nome da pasta de origem
            :dir_PD: Nome da paste de destino            
            :arquivo: Nome do arquivo para leitura (backup.parm)
    """
    origem = dir_HD
    destino = dir_PD
    cont_origem = 0
    cont_destino = 0

    #Leitura do Backup.parm
    backup = open(arquivo, "r")
    linha = backup.readline().replace("\n", "")

    #pega todos os arquivos do HD
    files_origem = os.listdir(origem)
    files_destino = os.listdir(destino)
    
    #Verificação dos arquivos a serem copiados caso exista
    while(linha != ""):
        for name_origem in files_origem: 
            if name_origem == linha:
                cont_origem += 1
        for name_destino in files_destino:
            if name_destino == linha:
                cont_destino += 1

        linha = backup.readline().replace("\n", "")  

    if cont_destino > 0 and cont_origem == 0:
        return True
    

def Backup_off(dir_HD, dir_PD,arquivo):
    """

        Essa função não faz o backup de arquivos entre o HD e um Pendrive, além do arquivo não está em nenhuma das pastas
       
        
        Inputs:           
            :origem: Nome da pasta de origem dos arquivos a serem transferidos
            :destino: Nome da pasta de destino dos arquivos transferidos 
            :backup: Arquivo Backup.parm para leitura dos arquivos a serem transferidos
            :linha: Linha do arquivo Backup.parm
            :files_origem: arquivos contidos no diretório de origem
            :files_destino: arquivos contidos no diretório de destino
            :name_origem: nome do arquivo na pasta origem
            :name_destino: nome do arquivo na pasta destino
            :cont_origem: contador para saber se existe o arquivo desejado na pasta origem
            :cont_destino: contador para saber se existe o arquivo desejado na pasta destino
            
        Returns:
            :: Retorna Falso por não fazer o backup e não ter o arquivo nas pastas

        Assertivas de Entrada:
            :dir_HD: Nome da pasta de origem
            :dir_PD: Nome da paste de destino            
            :arquivo: Nome do arquivo para leitura (backup.parm)
    """
    origem = dir_HD
    destino = dir_PD
    cont_origem = 0
    cont_destino = 0

    #Leitura do Backup.parm
    backup = open(arquivo, "r")
    linha = backup.readline().replace("\n", "")

    #pega todos os arquivos do HD
    files_origem = os.listdir(origem)
    files_destino = os.listdir(destino)

    #Verifica se as pastas estão vazias
    if files_origem == [] and files_destino == []:
        return False 
    
    #Verificação dos arquivos a serem copiados caso exista
    while(linha != ""):
        for name_origem in files_origem: 
            if name_origem == linha:
                cont_origem += 1
        for name_destino in files_destino:
            if name_destino == linha:
                cont_destino += 1

        linha = backup.readline().replace("\n", "")  

    if cont_destino == 0 and cont_origem == 0:
        print("Não fez backup e não possui os arquivos nas pastas solicitadas")
        return False
    

def PD_p_HD(dir_HD, dir_PD, arquivo):
    """

        Essa função não faz o backup de arquivos entre o HD e um Pendrive, além do ArqX pertence ao Pendrive
        
        Inputs:
            :origem: Nome da pasta de origem dos arquivos a serem transferidos
            :destino: Nome da pasta de destino dos arquivos transferidos 
            :backup: Arquivo Backup.parm para leitura dos arquivos a serem transferidos
            :linha: Linha do arquivo Backup.parm
            :files: arquivos contidos no diretório de origem
            :name: nome do arquivo a ser transferido
        Returns:
            :: Retorna Verdadeiro quando feito a transferência dos arquivos

        Assertivas de Entrada:
            :dir_HD: Nome da pasta de origem
            :dir_PD: Nome da pasta de destino
            :arquivo: Nome do arquivo para leitura (backup.parm)
    """
    origem = dir_HD
    destino = dir_PD

    #Leitura do Backup.parm
    backup = open(arquivo, "r")
    linha = backup.readline().replace("\n", "")

    #pega todos os arquivos do HD
    files = os.listdir(destino)

    #Verificação dos arquivos a serem copiados
    while(linha != ""):
        for name in files:
            if name == linha:
                shutil.copy2(os.path.join(destino,name), origem)
        linha = backup.readline().replace("\n", "")     

    return True
    
    