import backup
""""
    Module docstring
"""

def testa_impossivel():
    """
        Essa função verifica se existe algo no arquivo Backup.parm
        1º Caso de teste em que não possui o Backup.parm (Impossível)

        Inputs:
            :arquivo: nome do arquivo backup.parm
        Returns:
            :: Retorna falso por não ter nada escrito no backup.parm
            :: Retorna verdadeiro caso exista algum arquivo a ser procurado

    """
    arquivo = 'backup_parm.txt'
    assert not backup.backup(arquivo)

def testa_HDPendrive():
    """
        Essa função faz o backup de arquivos entre o HD e um Pendrive
        2º Caso de teste - HD para Pendrive

        Inputs:
            :arquivo: nome do arquivo backup.parm
            :dir_HD: diretório do HD para pesquisa do arquivo
            :dir_PD: diretório do Pen drive para pesquisa do arquivo
        Returns:
            :: Retorna verdadeiro se houve o backup para o Pendrive

    """
    arquivo = 'backup_parm.txt'
    dir_HD = "HD"
    dir_PD = "Pendrive"

    if (backup.backup(arquivo)):
        assert backup.HD_PenDrive(dir_HD, dir_PD,arquivo)

def testa_HD_H_PD():
    """
        Essa função faz o backup de arquivos entre o HD e um Pendrive
        3º Caso de teste - data HD > Pendrive (HD para Pendrive)

        Inputs:
            :arquivo: nome do arquivo backup.parm
            :dir_HD: diretório do HD para pesquisa do arquivo
            :dir_PD: diretório do Pen drive para pesquisa do arquivo
        Returns:
            :: Retorna verdadeiro se houve o backup para o Pendrive

    """
    arquivo = 'backup_parm.txt'
    dir_HD = "HD"
    dir_PD = "Pendrive"

    if (backup.backup(arquivo)):
        assert backup.True_Backup(dir_HD, dir_PD, arquivo)
        

#HD EQUAL PD
def testa_HD_E_PD():
    """
        Essa função faz o backup de arquivos entre o HD e um Pendrive
        4º Caso de teste - data HD == Pendrive (Faz nada)

        Inputs:
            :arquivo: nome do arquivo backup.parm
            :dir_HD: diretório do HD para pesquisa do arquivo
            :dir_PD: diretório do Pen drive para pesquisa do arquivo
        Returns:
            :: Retorna verdadeiro se o programa não fez nada

    """
    arquivo = 'backup_parm.txt'
    dir_HD = "HD"
    dir_PD = "Pendrive"

    if (backup.backup(arquivo)):
        assert backup.True_Backup(dir_HD, dir_PD, arquivo)

#HD MENOR PD
def testa_HD_M_PD():
    """
        Essa função faz o backup de arquivos entre o HD e um Pendrive
        5º Caso de teste - data HD < Pendrive (Erro)

        Inputs:
            :arquivo: nome do arquivo backup.parm
            :dir_HD: diretório do HD para pesquisa do arquivo
            :dir_PD: diretório do Pen drive para pesquisa do arquivo
        Returns:
            :: Retorna Falso caso ocorra um erro no programa
    """
    arquivo = 'backup_parm.txt'
    dir_HD = "HD"
    dir_PD = "Pendrive"

    if (backup.backup(arquivo)):
        assert not backup.True_Backup(dir_HD, dir_PD, arquivo)

def testa_N_backup():
    """
        Essa função não faz o backup de arquivos entre o HD e um Pendrive
        6º Caso de teste - Não faz o backup, mas o arquivo está presente apenas no HD (Erro)

        Inputs:
            :arquivo: nome do arquivo backup.parm
            :dir_HD: diretório do HD para pesquisa do arquivo
            :dir_PD: diretório do Pen drive para pesquisa do arquivo
        Returns:
            :: Retorna Falso caso houver erro no programa

    """
    arquivo = 'backup_parm.txt'
    dir_HD = "HD"
    dir_PD = "Pendrive"

    if (backup.backup(arquivo)):
        assert not backup.No_Backup(dir_HD, dir_PD, arquivo)

def testa_N_backup2():
    """
        Essa função não faz o backup de arquivos entre o HD e um Pendrive
        7º Caso de teste - Não faz o backup, mas o arquivo está presente nas duas pastas, data Pendrive < data HD (Erro)

        Inputs:
            :arquivo: nome do arquivo backup.parm
            :dir_HD: diretório do HD para pesquisa do arquivo
            :dir_PD: diretório do Pen drive para pesquisa do arquivo
        Returns:
            :: Retorna verdadeiro se houve o backup para o Pendrive

    """
    arquivo = 'backup_parm.txt'
    dir_HD = "HD"
    dir_PD = "Pendrive"

    if (backup.backup(arquivo)):
        assert not backup.No_Backup2(dir_HD, dir_PD, arquivo)

def testa_N_backup2_iguais():
    """
        Essa função faz o backup de arquivos entre o HD e um Pendrive
        8º Caso de teste - Não faz o backup, mas o arquivo está presente nas duas pastas, data Pendrive == data HD (Faz nada)

        Inputs:
            :arquivo: nome do arquivo backup.parm
            :dir_HD: diretório do HD para pesquisa do arquivo
            :dir_PD: diretório do Pen drive para pesquisa do arquivo
        Returns:
            :: Retorna verdadeiro se houve o backup para o Pendrive

    """
    arquivo = 'backup_parm.txt'
    dir_HD = "HD"
    dir_PD = "Pendrive"

    if (backup.backup(arquivo)):
        assert backup.No_Backup2(dir_HD, dir_PD, arquivo)

def testa_N_backup2_pd_maior():
    """
        Essa função faz o backup de arquivos entre o HD e um Pendrive
        9º Caso de teste - Não faz o backup, mas o arquivo está presente nas duas pastas, data Pendrive > data HD (Pendrive para HD)

        Inputs:
            :arquivo: nome do arquivo backup.parm
            :dir_HD: diretório do HD para pesquisa do arquivo
            :dir_PD: diretório do Pen drive para pesquisa do arquivo
        Returns:
            :: Retorna verdadeiro se houve o backup para o Pendrive

    """
    arquivo = 'backup_parm.txt'
    dir_HD = "HD"
    dir_PD = "Pendrive"

    if (backup.backup(arquivo)):
        assert backup.No_Backup2(dir_HD, dir_PD, arquivo)

def testa_sem_arquivo():
    """
        Essa função faz o backup de arquivos entre o HD e um Pendrive
        10º Caso de teste - Faz o backup, porém nenhuma das pastas possui o arquivo (Erro)

        Inputs:
            :arquivo: nome do arquivo backup.parm
            :dir_HD: diretório do HD para pesquisa do arquivo
            :dir_PD: diretório do Pen drive para pesquisa do arquivo
        Returns:
            :: Retorna verdadeiro se houve o backup para o Pendrive

    """
    arquivo = 'backup_parm.txt'
    dir_HD = "HD"
    dir_PD = "Pendrive"

    if (backup.backup(arquivo)):
        assert not backup.No_Arquivos(dir_HD, dir_PD, arquivo)

def testa_pd_arquivo():
    """
        Essa função faz o backup de arquivos entre o HD e um Pendrive
        11º Caso de teste - Faz o backup, porém apenas a pasta pendrive tem o arquivo (Faz nada)

        Inputs:
            :arquivo: nome do arquivo backup.parm
            :dir_HD: diretório do HD para pesquisa do arquivo
            :dir_PD: diretório do Pen drive para pesquisa do arquivo
        Returns:
            :: Retorna verdadeiro se houve o backup para o Pendrive

    """
    arquivo = 'backup_parm.txt'
    dir_HD = "HD"
    dir_PD = "Pendrive"

    if (backup.backup(arquivo)):
        assert backup.Pd_arquivo(dir_HD, dir_PD, arquivo)

def testa_temBackup():
    """
        Essa função não faz o backup de arquivos entre o HD e um Pendrive
        12º Caso de teste - Possui o backup.parm, porém não existe o arquivo nas pastas nem realiza o backup (Erro)

        Inputs:
            :arquivo: nome do arquivo backup.parm
            :dir_HD: diretório do HD para pesquisa do arquivo
            :dir_PD: diretório do Pen drive para pesquisa do arquivo
        Returns:
            :: Retorna verdadeiro se houve o backup para o Pendrive

    """
    arquivo = 'backup_parm.txt'
    dir_HD = "HD"
    dir_PD = "Pendrive"

    if (backup.backup(arquivo)):
        assert not backup.Backup_off(dir_HD, dir_PD, arquivo)

def testa_pd_para_hd():
    """
        Essa função não faz o backup de arquivos entre o HD e um Pendrive
        13º Caso de teste - Possui o backup.parm, porém não existe o arquivo nas pastas nem realiza o backup (Pendrive para HD)

        Inputs:
            :arquivo: nome do arquivo backup.parm
            :dir_HD: diretório do HD para pesquisa do arquivo
            :dir_PD: diretório do Pen drive para pesquisa do arquivo
        Returns:
            :: Retorna verdadeiro se houve o backup para o Pendrive

    """
    arquivo = 'backup_parm.txt'
    dir_HD = "HD"
    dir_PD = "Pendrive"

    if (backup.backup(arquivo)):
        assert backup.PD_p_HD(dir_HD, dir_PD, arquivo)